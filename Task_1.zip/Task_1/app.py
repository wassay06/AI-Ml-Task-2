# app.py
import streamlit as st
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

# Load the fine-tuned model and tokenizer
model = AutoModelForSequenceClassification.from_pretrained("./bert_news_classifier")
tokenizer = AutoTokenizer.from_pretrained("./bert_news_classifier")

# Streamlit app
st.title("News Topic Classifier")
st.write("Enter a news headline to predict its topic (World, Sports, Business, Sci/Tech).")
user_input = st.text_input("Enter a news headline:")

if user_input:
    inputs = tokenizer(user_input, return_tensors="pt", padding=True, truncation=True)
    with torch.no_grad():
        outputs = model(**inputs)
    prediction = outputs.logits.argmax().item()
    topics = {0: "World", 1: "Sports", 2: "Business", 3: "Sci/Tech"}
    st.write(f"Predicted Topic: {topics[prediction]}")