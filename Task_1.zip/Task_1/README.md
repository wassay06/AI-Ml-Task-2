# Task 1: News Topic Classifier Using BERT

## Objective
Build a news topic classifier using BERT to classify AG News dataset headlines into 4 categories: World, Sports, Business, Sci/Tech.

## Dataset
- AG News dataset from Hugging Face (`datasets` library).
- Training: 5,000 samples, Test: 1,000 samples.

## Approach
- Fine-tuned `bert-base-uncased` model using Hugging Face Transformers.
- Evaluated using accuracy and F1-score.
- Deployed using Streamlit for user input and prediction.

## Results
- Fine-Tuned Accuracy: [e.g., 0.92]
- Fine-Tuned F1-Score: [e.g., 0.91]

## How to Run
1. Create and activate virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   .\venv\Scripts\activate   # Windows