# news_classifier.py
# Import necessary libraries
import pandas as pd
import numpy as np
from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
from sklearn.metrics import accuracy_score, f1_score
import torch

# Step 1: Load AG News Dataset
print("Loading AG News Dataset...")
dataset = load_dataset("ag_news")

# Step 2: Preprocess the dataset
tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

def tokenize_function(examples):
    return tokenizer(examples["text"], padding="max_length", truncation=True)

# Tokenize train and test datasets (smaller subsets for speed)
train_dataset = dataset["train"].shuffle(seed=42).select(range(2000))  # 2,000 rows
test_dataset = dataset["test"].shuffle(seed=42).select(range(500))     # 500 rows
tokenized_train = train_dataset.map(tokenize_function, batched=True)
tokenized_test = test_dataset.map(tokenize_function, batched=True)

# Step 3: Load BERT model
print("Loading BERT Model...")
model = AutoModelForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=4)

# Step 4: Define compute metrics function
def compute_metrics(pred):
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    acc = accuracy_score(labels, preds)
    f1 = f1_score(labels, preds, average="weighted")
    return {"accuracy": acc, "f1": f1}

# Step 5: Training arguments
training_args = TrainingArguments(
    output_dir="./results",
    eval_strategy="epoch",
    save_strategy="epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=4,  # Reduced for CPU
    per_device_eval_batch_size=4,
    num_train_epochs=2,
    weight_decay=0.01,
    load_best_model_at_end=True,
    metric_for_best_model="f1",
)

# Step 6: Initialize Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_train,
    eval_dataset=tokenized_test,
    compute_metrics=compute_metrics,
)

# Step 7: Train the model
print("Starting Fine-Tuning...")
trainer.train()

# Step 8: Evaluate the model
eval_results = trainer.evaluate()
print("\nFine-Tuned Accuracy:", eval_results['eval_accuracy'])
print("Fine-Tuned F1-Score:", eval_results['eval_f1'])

# Step 9: Save the model
model.save_pretrained("./bert_news_classifier")
tokenizer.save_pretrained("./bert_news_classifier")
print("Model saved successfully.")